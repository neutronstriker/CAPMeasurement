/*
 * CAPMeasurement.cpp
 *
 * Created: 10-01-2016 11:46:04
 *  Author: neutron

we can implement autoranging by detecting timer has overflown by checking Tov flag

we need to implement a uart_printFloat(float num,...)
{
use varlist and specify precision
default is 2
multiply number with 10 raised to power of precision and print them as separate numbers with a dot in between use printnum()
}
 */ 


#include <avr/io.h>
#include "../../uartlib.h"
#include <util/delay.h>
#include <avr/interrupt.h>

void adc_init();
unsigned int adc_read(unsigned char channel);
void configure_AnalogComparator();
void configure_Timer_and_ICP();
void startTimer();
void stopTimer();
void resetTimer();
uint16_t readICPdata();
uint16_t readVoltage(uint8_t channel);
void calculateCapacitance();

#define VOLTAGE_DIVIDER 1 //direct connection 
#define RC_RESISTOR_1 100000UL //100k
#define RC_RESISTOR_2 1000UL //1k
#define RC_RESISTOR_1_PIN	4 //PORTD pin 4
#define RC_RESISTOR_2_PIN	3 //PORTD pin 3
#define DIVIDE_BY_1		0x01
#define DIVIDE_BY_8		0x02
#define DIVIDE_BY_64	0x03
#define DIVIDE_BY_256	0x04
#define DIVIDE_BY_1024	0x05

#define TIMER_MIN_SPEED 5
#define TIMER_MAX_SPEED 1

float time_period=2;
uint8_t timerSpeed = TIMER_MAX_SPEED;

int main(void)
{
	uart_init(9600);
	u_printPMEM("Board Initialized\r\n");
	adc_init();
	
	DDRB |= (1<<5);
	
	//initially set all RC_RESISTORS as INPUT LOW, so that both resistors are not active same time ever.
	DDRD &= ~((1<<RC_RESISTOR_1_PIN) | (1<<RC_RESISTOR_2_PIN));
	PORTD &= ~((1<<RC_RESISTOR_1_PIN) | (1<<RC_RESISTOR_2_PIN));
    
	while(1)
    {
		/*
		uart_printnum((adc_read(2)*1100UL*11UL)/1024UL);
		
		u_print("mV\r\n");
		_delay_ms(500);
		*/
		/*
		uart_printFloat(34.45896,3);
		u_print("\r\n");
		*/
		calculateCapacitance();
		/*
		//testing analog comparator
		if(ACSR & (1<<ACO))
			PORTB |= (1<<5);
		else PORTB &= ~(1<<5);
		*/
			
        //TODO:: Please write your application code 
    }
}

void adc_init()
{
	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0); //clk divided by 128 for highest accuracy.
	ADMUX = (1<<REFS0)|(1<<REFS1) ; //Internal Vbg 1.1V as Reference
}

unsigned int adc_read(unsigned char channel)
{
	ADMUX |= (0b00001111 & channel); //there are some other uses of channel values beyond 0-7, read datasheet of 328p for more clarification.
	ADCSRA |= (1<<ADSC);
	while((ADCSRA & (1<<ADIF)) == 0);
	ADCSRA |= (1<<ADIF);
	return ADC;
}

void configure_AnalogComparator()
{
	ADCSRA &= ~(1<<ADEN);	//disable ADC since we will be using one of ADC channels as VIN- for Comparator.
	ADMUX = 0;	//selecting channel i.e. pin A0 as VIN- substitute the principle is same as selecting ADC channel for ADC conversion
				//however since we don't need REFS I am removing the overhead required in retaining those settings.
	ADCSRB |= (1<<ACME);
	ACSR = (1<<ACIC);	//enable Comparator, don't select Vbg as VIN+, no interrupts, Connect output to ICP1.
}

void configure_Timer_and_ICP()
{
	PRR &= ~(1<<PRTIM1); //Enable Timer1 (in power reduction register PRR)
	TIFR1 |= (1<<ICF1); //clear the Input Capture Interrupt flag, which was set due to change the ICP source from pin to ACO.
	TCCR1A = 0;
	TCCR1B = 0; //clear all settings 
	TCCR1B &= ~(1<<ICES1); //Capture on Falling edge.
	TIMSK1 = (1<<ICIE1);
}

void startTimer(uint8_t val)
{
	TCCR1B &= ~(0x07);
	switch(val)
	{
		case 1:	TCCR1B |= (DIVIDE_BY_1);
		time_period = 0.0625;
		break;
		case 2:	TCCR1B |= (DIVIDE_BY_8);
		time_period = 0.5;
		break;
		case 3:	TCCR1B |= (DIVIDE_BY_64);
		time_period = 4UL;
		break;
		case 4:	TCCR1B |= (DIVIDE_BY_256);
		time_period = 16UL;
		break;
		case 0:
		case 5:	TCCR1B |= (DIVIDE_BY_1024);
		time_period = 64UL;
		break;
		default:break;
	}
	
	//TCCR1B  |= (DIVIDE_BY_256);
}

void stopTimer()
{
	TCCR1B &= ~0x07;
}

void resetTimer()
{
	TCNT1 = 0;	
}

uint16_t readICPdata()
{
	return ICR1;
}

void calculateCapacitance()
{
	timerSpeed = TIMER_MAX_SPEED;
TEST:
	stopTimer();
	
	adc_init();
	
	DDRD |= (1<<RC_RESISTOR_2_PIN); //set the GPIO pin as OUPUT
	PORTD &= ~(1<<RC_RESISTOR_2_PIN);
	
	while(!(readVoltage(0) <= 50));//wait until voltage on CAP less than 50mV(decrease value for accuracy), channel 0 is also the VIN- of ACO
	
	_delay_ms(50);
	
	configure_AnalogComparator();
	configure_Timer_and_ICP();
	resetTimer();
	
	PORTD |= (1<<RC_RESISTOR_2_PIN);
	startTimer(timerSpeed);
	while(!(TIFR1 & (1<<ICF1)))	//wait until ICF1 flag is set.
	{
		if(TIFR1 & (1<<TOV1))	//if timer has overflown before an Input capture has been registered
		{						//increase time period and restart function.
			//timerSpeed = (++timerSpeed)/TIMER_MIN_SPEED; //this statement doesn't work, C compiler unable to understand, so I wrote it below like this
			TIFR1 |= (1<<TOV1); //clear timer overflow flag first
			timerSpeed = (timerSpeed+1)%TIMER_MIN_SPEED;
			goto TEST;
		}
	}
	stopTimer();
	
	//we know at 0.7RC voltage will reach 0.5Vs
	//so 0.7RC = ourICP data
	//C = timing/0.7R
	uint16_t timing = readICPdata();
	
	//1000000000 * 0.5us = 1000 * 0.5s, i multiplied 1000000000 to get cap value in nanofarad.
	//timing * 0.5us is our actual time, since ICP data only contains number of clocks with a period of 0.5us went in.
	//100Ul * 5UL/0.7
	//10UL*5UL/7UL
	
	uint32_t capacitance = (1000000UL * time_period * timing)/(0.7 * RC_RESISTOR_2); 
	u_print("timing=");
	uart_printnum(timing);
	u_print("  ");
	u_print("capacitance=");
	uart_printnum(capacitance);
	u_print("pF or ");
	uart_printnum(capacitance/1000UL);
	u_print("nF or ");
	uart_printFloat((float)capacitance/1000000UL,3);
	u_print("uF\r\n");
	u_print("timer_speed = ");
	uart_printnum(timerSpeed);
	u_print("\r\n");
	
}

uint16_t readVoltage(uint8_t channel)
{
	return ((adc_read(channel)*1100UL*VOLTAGE_DIVIDER)/1024UL);
}

ISR(TIMER1_CAPT_vect)
{
	
}

/*
timer_speed = 4timing=42879  capacitance=9800914pF or 9800nF or 9.800uF
timer_speed = 4timing=42873  capacitance=9799543pF or 9799nF or 9.799uFtimer_speed = 4timing=21296  capacitance=19470630pF or 19470nF or 19.470uF
timer_speed = 0timing=21294  capacitance=19468800pF or 19468nF or 19.468uF
timer_speed = 0timing=21291  capacitance=19466056pF or 19466nF or 19.466uF
timer_speed = 0

with this data i found that it cannot calculate beyond 60uf using a 100k resistor
we will need to need to decrease resistor value for that.

Anyway 100k is pretty good for pf scale since i was able to quite accurately measure 22pf and 33pf
and i found for the first time that actually manufacturing process variation by identify same capacitors
from a pack lets say for 270pf out of 5 three actually where close to 270pf one was 280pf and one was 247pf

i found similar variation in many cap values, first i thought it was my circuit parasitic capacitance problem
so i placed them in various ways and inserted in different holes of breadboard always same result, then
i thought maybe my program gives wrong result, but i understood that it is manufacturing process variation or ageing 
effect when i found that from one pack like 270pf i got many values as well as the right ones. I also found that
22pf was showing 21pf and 33pf was showing 31pf so there shouldn't be much error for higher values.


Ok so i thought if i can try this trick which is connect a 1k from another gpio and keep it hiZ state when a speed 0/5 timer
overflows then we make 100k gpio to hiz state and start using 1k and also change the value in the equation accordingly, now
this should theoretically gives us a range of 6000UF.

Next i would like to do some small changes in program and get this same setup to measure inductance
the concept is same here the voltage rises there the voltage will drop and some change in calculation formula.
*/

/*
Default Pins for VIN+ and VIN- are PD6 and PD7 respectively.

We have to connect the reference to VIN+ of Analog Comparator.

VCC
+
R1
++++++AIN0
R2
+
GND

R1=R2 = 10k or 1k so that we can make sure the reference voltage is exactly what I wanted
like if I am using 0.7RC then reference should be 0.5Vs and if I am using 5RC then 0.99Vs.

For 0.99Vs the resistors to be used should be R1=1k and R2=100k.

Circuit for CAP will be

GPIO +++++ Rmeas+++++++ VIN-/ADC_PIN
				+
				+
			CAPACITOR(dut)
				+
				+
				+
				+
				GND
				
ADC will be using Internal 1.1V reference. So I am now counting on the accuracy of the Vbg 1.1v
and also the accuracy of the resistors. Because either I can try to measure the accuracy of supply
voltage or if I am sure that Supply is accurate I can measure the reference of VIN- of comparator
is accurately divided by the resistors. I can't measure the accuracy of both of them. Because in
an equation we can find two unknowns, only one is possible to find, if we know other one.

So I thought for now lets get away with the accuracy measurements and focus on concept.

And the operation sequence will be first we will use our Rmeas and short the capacitor to ground
by pulling the GPIO LOW and at that time we will start measuring voltage across CAP using ADC pin, 
and once it reaches quite close to 0(zero) we will start the measurement function.

Measurement function will set first the ADC pin as analog comparator's VIN- and make the Analog 
comparator ready for measurement, set all the interrupts properly and make the timer ready for
running.

Then we will set the GPIO to high and next instruction we will start the timer.

We wait for the Comparator output falling edge(output going low), since initially the VIN+ will be connected
to Vref (which is 0.5Vs) and which will initially higher than voltage across CAP at time T=0.

Once the Voltage across CAP reaches(or goes beyond Vref) we will have a Comparator Interrupt which will
trigger the INPUT CAPTURE and we will save the value from Timer_1 ICP1 register and take the Timer Time
period and start the calculation and print the CAPACITANCE measured value on UART.

For more accurate relation between Vs and Vref we can make the Higher end of the Voltage divider connect
to one of GPIO pins so that the difference between Vs and Voh is doesn't affect Vref. But some pins at
some instant may have a different Voh. So I thought of another thing but I am not sure it will work
that is we can connect the High end of Vref Voltage divider to the GPIO controlling the CAP but, there
is one problem with this because when the measurement is started the Comparator wants that the VIN+ already
connected to Vref, but at time T=0, now Vref will be zero, so we may need to initialize Comparator after
a few cycles but that will also loose accuracy, So we will compromise anyway at some point with accuracy.

*/